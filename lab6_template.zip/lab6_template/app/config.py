import os

SECRET_KEY = '6b6efc5ddc3057b5272312643f85a73f1b3349fd493e1a4d8ce138caff0a8e9c'
SQLALCHEMY_DATABASE_URI = 'mysql+mysqlconnector://std_1684_lab6:Gg9772891@std-mysql.ist.mospolytech.ru/std_1684_lab6'
SQLALCHEMY_TRACK_MODIFICATIONS = True
SQLALCHEMY_ECHO = True

UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'media', 'images')